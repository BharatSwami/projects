# -*- coding: utf-8 -*-
"""
Created on Fri Apr 21 09:59:58 2023

@author: apajuelo
"""

import pandas as pd
import numpy as np

assets = pd.read_csv('prices.csv', sep=";", index_col=0, parse_dates=True, 
                   infer_datetime_format=True) 

# ";" is used as sep because my computer is set up in Spanish

#Calculation of average return

ret = assets.pct_change().dropna()
print(ret.head())

ret_bond = ret['Bond'].mean(axis=0)
print('Daily mean return of the bond:',ret_bond)

ret_eq = ret['Equity_ETF'].mean(axis=0)
print('Daily mean return of the equity ETF:',ret_eq)

ret_cr = ret['Crypto_ETF'].mean(axis=0)
print('Daily mean return of the crypto ETF:',ret_cr)

#Calculation of volatility

vol_bond = ret['Bond'].std(axis=0)
print('Daily volatility of the bond:', vol_bond)

vol_eq = ret['Equity_ETF'].std(axis=0)
print('Daily volatility of the equity ETF:', vol_eq)

vol_cr = ret['Crypto_ETF'].std(axis=0)
print('Daily volatility of the crypto ETF:', vol_cr)

#Calculation of skewness

skew_bond = ret['Bond'].skew(axis=0)
print('Daily skewness of the bond:', skew_bond)

skew_eq = ret['Equity_ETF'].skew(axis=0)
print('Daily skewness of the equity ETF:', skew_eq)

skew_cr = ret['Crypto_ETF'].skew(axis=0)
print('Daily skewness of the crypto ETF:', skew_cr)

#Calculation of kurtosis

kurt_bond = ret['Bond'].kurt(axis=0)
print('Daily kurtosis of the bond:', kurt_bond)

kurt_eq = ret['Equity_ETF'].kurt(axis=0)
print('Daily kurtosis of the equity ETF:', kurt_eq)

kurt_cr = ret['Crypto_ETF'].kurt(axis=0)
print('Daily kurtosis of the crypto ETF:', kurt_cr)

#Correlation matrix

corr_matrix = ret.corr()
print("Correlation matrix")
print(corr_matrix)

#Covariance matrix

cov_matrix = ret.cov()
print("Covariance matrix")
print(cov_matrix)

#Portfolio statistics

weight = np.array([0.6, 0.6, -0.2])
weight = weight.reshape(-1,1)

#Weighted return

avg_ret = ret.mean(axis=0)

port_ret = weight.T @ avg_ret

print('Weighted portfolio return:',port_ret)

#Portfolio variance

var_port = weight.T @ cov_matrix @ weight

print('Portfolio variance:', var_port.values)

#Spearman correlation

sp_corr = ret.corr(method='spearman')
print('Spearman correlation matrix')
print(sp_corr)

